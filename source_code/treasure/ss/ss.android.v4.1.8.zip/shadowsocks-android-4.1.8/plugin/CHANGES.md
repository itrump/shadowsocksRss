* 0.0.3:
  * Update support library version to 25.2.0.
* 0.0.2:
  * Add `getOrDefault` to `PluginOptions`;
  * Update support library version to 25.1.1.
* 0.0.1: Initial release.
