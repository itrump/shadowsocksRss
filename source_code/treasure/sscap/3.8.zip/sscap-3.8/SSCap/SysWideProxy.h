#pragma once

BOOL EnableSysWideProxy( HWND hParentHwnd  ,BOOL bEnable ,BOOL bGlobalMode, BOOL bPopupMsg );
BOOL ChangeSysProxyMode( HWND hParentHwnd, BOOL bGlobalMode );
