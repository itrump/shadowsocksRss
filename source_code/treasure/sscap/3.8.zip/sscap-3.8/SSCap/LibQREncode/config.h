#ifndef CONFIG_H
#define CONFIG_H

// manual config.h for microsoft visual studio

#define HAVE_STRDUP 1

#define __STATIC static

#define MAJOR_VERSION 1
#define MINOR_VERSION 0
#define MICRO_VERSION 0
#define VERSION ""

#endif
