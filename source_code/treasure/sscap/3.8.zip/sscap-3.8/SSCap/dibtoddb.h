#pragma once

HBITMAP DIBToDDB( HANDLE hDIB ); 